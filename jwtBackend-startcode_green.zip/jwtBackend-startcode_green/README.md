# jwtBackend

Start code for exercise given at cphbusiness.dk - computer science
