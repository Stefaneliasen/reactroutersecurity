import React, { Component } from 'react';
import {BrowserRouter as Router, Route, Link, Switch} from "react-router-dom";


const Welcome = () => (
  <div>
    <h2>Hello all friendly users ;-)</h2>
     <ul>
        <li><Link to="/allusers">All Users</Link></li>
      </ul>
  </div>
)

class App extends Component {
  constructor() {
    super()
    this.state = {
      data: []
    }
  }

  componentDidMount(){
    const data = this.props.data.users
    this.setState({
      data: data
    })
  }

  render() {

    return (
      <div>
      <Router>
        <Switch>
        <Route exact path="/" component={Welcome}/>
        <Route path="/allusers" render={ () => <AllUsers data={this.state.data}/>}/>
        <Route path="/details/:name" render={ ({match}) => <Details data={this.state.data} user={match.params.name}/>}/>
        </Switch>
      </Router>
      </div>
      
    );
  }
  
}

class AllUsers extends React.Component {

  render(){
    
    const users = this.props.data.map(user => <tr key={user.first}><td><img src={user.picture.thumbnail}/></td><td>{user.first} {user.last}</td><td><Link to={`/details/${user.first}`}>Details</Link></td></tr>)
    return (
    <div>
      <h2>Welcome til stefans mor</h2>
        <ul>
          <li><Link to="/">Welcome page</Link> </li>
        </ul>
      <table>
        <thead>
          <tr><th>Picture</th><th>Name</th><th>Details</th></tr>
        </thead>
        <tbody>
          {users}
        </tbody>
      </table>
    </div>
    )
  }
}

class Details extends Component {
  render() {
    var chosenUser = this.props.data.find(data => data.first == this.props.user)
    if(chosenUser) {
      return (
        <div>
            <h2>Details for: {chosenUser.first} {chosenUser.last}</h2>
            <img src={chosenUser.picture.large} />
            <ul>
              <li>Cell: {chosenUser.cell}</li>
              <li>City: {chosenUser.city}</li>
              <li>Dob: {chosenUser.dob}</li>
              <li>Email: {chosenUser.email}</li>
              <li>Gender: {chosenUser.gender}</li>
              <li>Phone: {chosenUser.phone}</li>
              <li>State: {chosenUser.state}</li>
              <li>Street: {chosenUser.street}</li>
              <li>Title: {chosenUser.title}</li>
              <li>Zip: {chosenUser.zip}</li>
            </ul>
          <Link to="/allusers"><h3>Back</h3></Link>
        </div>
      )
    } else {
      return (
        <div></div>
      )
    }
  }
}

export default App;
