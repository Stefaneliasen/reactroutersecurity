import React, { Component } from 'react';
import {
  HashRouter as Router,
  Route,
  NavLink,
  Switch
} from 'react-router-dom'

class App extends Component {
  render() {
   
    return (
      <Router>
      <div>
      <Header />
        <Switch>
        <Route exact path="/" render={() => <Home />} />
        <Route path="/products" render={() => <Product BookStore={this.props.BookStore}/>} />
        <Route path="/company" render={() => <Company />} />
        <Route path="/addbook" render={() => <AddBook BookStore={this.props.BookStore}/>} />
        <Route component={NoMatch}/>
        </Switch>
      </div>
  </Router>
    );
  }
}
const Header = () => (
  
<div>
<ul className="header">
  <li><NavLink exact activeClassName="active" to="/">Home</NavLink></li>
  <li><NavLink activeClassName="active" to="/products">Products</NavLink></li>
  <li><NavLink activeClassName="active" to="/company">Company</NavLink></li>
  <li><NavLink activeClassName="active" to="/addbook">Add Book</NavLink></li>
</ul>
</div>

);
const Company = () => (
<div>
  <h2>fortnite and epic games was won</h2>
</div>
);

const Home = () => (
<div>
  <h2>welcome 2 home</h2>
</div>
);

const NoMatch = ({ location }) => (
  <div>
    <h3>
      No match for <code>{location.pathname}</code>
    </h3>
  </div>
);

class Product extends Component {
  constructor(props){
    super(props);
    this.state = {
      books: props.BookStore.getBooks()
    }
  }
render() {
  console.log(this.state.books);
  const books = this.state.books.map(books => <ul key={books.id}><li>{books.title}</li></ul>)
return (
  <div>
    {books}
  </div>
  )
  }
}
class AddBook extends Component {
  constructor(props){
    super(props);
    this.state = {
      book: {id: "", title: "", info: ""}
    }
  }

  handleSubmit = (evt) => {
    evt.preventDefault();
    const book = this.state.book;
    this.props.BookStore.addBook(book);
  }

  handleInput = (event) => {
    const target = event.target;
    const prop = target.id;
    var value = target.value;
    var book = this.state.book;
    book[prop] = value;
    this.setState({
      book : book
    });
  }
render() {
 
return (
  <div>
<form onSubmit={this.handleSubmit}>
<input  name="title" placeholder="Title" value={this.state.book.title} onChange={this.handleInput} id="title"/>
<br/>
<input  name="info" placeholder="Information" value={this.state.book.info} onChange={this.handleInput} id="info"/>
<br/>
<button type="submit" className="btn btn-default">Add book</button>
</form>
  </div>
  )
  }
}


export default App;
