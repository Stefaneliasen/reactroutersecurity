import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import bookStore from './BookStore';

ReactDOM.render(<App BookStore={bookStore}/>, document.getElementById('root'));
registerServiceWorker();
